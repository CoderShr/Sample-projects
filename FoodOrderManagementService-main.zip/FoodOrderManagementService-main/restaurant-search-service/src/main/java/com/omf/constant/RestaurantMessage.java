package com.omf.constant;

public class RestaurantMessage {

    public static final String CREATED = "Restaurant created successfully.";
    public static final String ALREADY_EXIST = "Restaurant name already exist.";
}
