package com.omf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OrderingServiceApp {
    public static void main(String[] args) {
        SpringApplication.run(OrderingServiceApp.class, args);
    }
}

