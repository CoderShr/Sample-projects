package com.mindtree.exception;

public class InvalidStateCodeException extends RuntimeException {

	private static final long serialVersionUID = -6038392535940525635L;

	public InvalidStateCodeException(String message) {
		super(message);
	}

}
