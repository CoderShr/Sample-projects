package com.mindtree.exception;

public class InvalidInputException extends Exception {

	private static final long serialVersionUID = -8293139401481598440L;

	public InvalidInputException(String message) {
		super(message);
	}

}
