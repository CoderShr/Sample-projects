package com.order.configServer.foodserviceconfigserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FoodServiceConfigServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
