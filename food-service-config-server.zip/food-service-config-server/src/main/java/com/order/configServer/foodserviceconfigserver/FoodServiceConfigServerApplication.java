package com.order.configServer.foodserviceconfigserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FoodServiceConfigServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(FoodServiceConfigServerApplication.class, args);
	}

}
