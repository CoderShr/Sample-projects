package com.order.foodserviceeureka;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FoodServiceEurekaApplicationTests {

	@Test
	void contextLoads() {
	}

}
