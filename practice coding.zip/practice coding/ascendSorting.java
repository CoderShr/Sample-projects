/* package codechef; // don't place package name! */

import java.util.*;
import java.lang.*;
import java.io.*;
import java.util.stream.*;

/* Name of the class has to be "Main" only if the class is public. */
class Main
{
 public static void main(String args[])  
{  
    int[] a = {3,4,7,0,2,6,1,7,45,68,2,4,7,24,89,42};
    System.out.println("Before sorting:");  
    for(int i = 0; i<a.length; i++){
        System.out.print(a[i] + " "); 
    }
    
    int temp = 0;
    for(int i = 0; i<a.length; i++){
        for(int j = i+1; j < a.length; j++) {
    
        
        if(a[i] < a[j]){
            temp = a[i];
            a[i] = a[j];
            a[j] = temp;
        }
    }
    }
    
    System.out.println("\nAfter sorting:");  
    for(int i = 0; i<a.length; i++){
        System.out.print(a[i] + " "); 
    }
     
}  
}

