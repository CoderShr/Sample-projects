/* package codechef; // don't place package name! */

import java.util.*;
import java.lang.*;
import java.io.*;

public class Main
{
    public static void main(String[] args) {
        int[] numArray = new int[] {3,5,4,10,11,7,6,18,9,8};
        Main main = new Main();
        if(main.isConsecutiveElementArray(numArray)){
            System.out.println("consective array");
        } else {
            System.out.println("not consective array");
        }
    }
    
    public boolean isConsecutiveElementArray(int[] numArray) {
        boolean isConsecutive = false;
        Arrays.sort(numArray);
        for(int i = 0; i<numArray.length; i++){
        System.out.println(numArray[i]);
            if(i+1 < numArray.length && numArray[i+1] != numArray[i]+1){
                return false;
            } else {
                isConsecutive =  true;
            }
        }
        return isConsecutive;
    }
      
      
      
    
    
}

