/* package codechef; // don't place package name! */

import java.util.*;
import java.lang.*;
import java.io.*;

/* Name of the class has to be "Main" only if the class is public. */
class Main
{
	public static void main (String[] args) throws java.lang.Exception
	{
	    int[] numArray = new int[]{45,48,35,6,3,63,34,24,3,4,34,54,35};
	    Main main = new Main();
	    int num = main.getFirstRepeatingElementInArray(numArray);
	    if(num != -1){
	        System.out.println(num);
	    } else{
	    System.out.println("No elements repeated in array");
	    }
	}
	
	public int getFirstRepeatingElementInArray(int[] intArray){
	    Map<Integer, Integer> map = new LinkedHashMap<>();
	    for(int i : intArray){
	        if(map.containsKey(i)){
	            map.put(i, map.get(i)+1);
	        } else {
	            map.put(i, 1);
	        }
	    }
	    for(Map.Entry<Integer, Integer> mp: map.entrySet()){
	        if(mp.getValue() >1){
	            return mp.getKey();
	        }
	    }
	    
	    return -1;
	}
}
