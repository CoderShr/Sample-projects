/* package codechef; // don't place package name! */

import java.util.*;
import java.lang.*;
import java.io.*;

/* Name of the class has to be "Main" only if the class is public. */
class Main
{
 public static void main(String args[])  
   {  
     int num = 5;
     Main main = new Main();
     main.findFatorial(num);
}

public void findFatorial(int num){
    int fact = 1 ;
    for(int i =1; i<= num ; i++){
        fact = fact*i;
    }
    
    System.out.println(fact);
}
}
