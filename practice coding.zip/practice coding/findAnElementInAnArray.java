/* package codechef; // don't place package name! */

import java.util.*;
import java.lang.*;
import java.io.*;

/* Name of the class has to be "Main" only if the class is public. */
class Main
{
	public static void main (String[] args) throws java.lang.Exception
	{
	   int arr[]={16,19,21,25,3,5,8,10};
	    
	    Main main = new Main();
	   
	    main.findAllSubString(arr, 8);
	}
	
	public void findAllSubString(int[] arr, int num){
	    for(int i =0; i< arr.length; i++){
	       if(arr[i] == num) {
	           System.out.println(num +" is present in index : " + i);
	       }
	    }
	    
	}
	
}
