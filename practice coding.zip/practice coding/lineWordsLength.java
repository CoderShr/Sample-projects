
// Online IDE - Code Editor, Compiler, Interpreter

public class Main
{
    public static void main(String[] args) {
               
        // ---------------  Solution 1  ----------------------------- //
        String str = "Hello world How are You";
        String[] s = str.split("\\s");
        System.out.println("Count using String methods");
        for(String ss : s){
            System.out.println(ss + " - " + ss.length());
        }
        
        
        // --------------------  solution 2  ---------------------- //
        char[] ch = str.toCharArray();
        System.out.println("Count using char array loop iterations");
        for(int i = 0; i< ch.length ; i++){
            String countAlp = "";
            while(i< ch.length && ch[i] != ' '){
                countAlp += ch[i];
                i++;
            }
            if(countAlp.length() > 0)
            System.out.println(countAlp + " - " + countAlp.length());
        }
    }
       
}
