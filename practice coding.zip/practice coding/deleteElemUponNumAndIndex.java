import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter n:");
        int n = sc.nextInt();
        System.out.println("Enter index:");
        int index = sc.nextInt();
        int[] numArray = new int[]{2,4,5,6,9,10,8,11,3,0,12,1,7};
        int[] result = deleteAnArray(numArray, n);
        System.out.println("\nDeleted array on specifc number :  " + Arrays.toString(result));
        deleteArrayOfSpecificIndex(numArray, index);
        // 69 - 44
    }
    
    static int[] deleteAnArray(int[] numArray, int num) {
        int[] deletedSpecificNumberOfArray = new int[numArray.length-1];
        // delete specific num from array
        int i = 0; 
        for(int n : numArray){
            if(n != num){
                deletedSpecificNumberOfArray[i] = n;
                i ++;
            }
        }
        return deletedSpecificNumberOfArray;
    }
    
    static void deleteArrayOfSpecificIndex(int[] numArray, int index){
        // delete specific index element from array 
        int[] deletedSpecificIndexOfArray = new int[numArray.length-1];
        for(int j=0, k=0 ;j< numArray.length; j++){
            if(index == j){
                continue;
            }
            deletedSpecificIndexOfArray[k++] = numArray[j];
        }
        System.out.println("Deleted array on specific index :  " + Arrays.toString(deletedSpecificIndexOfArray));
    }

    }