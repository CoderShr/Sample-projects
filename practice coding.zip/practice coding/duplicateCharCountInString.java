/* package codechef; // don't place package name! */

import java.util.*;
import java.lang.*;
import java.io.*;

public class Main
{
    public static void main(String[] args) {
    String str1 = "malayalamManorama";
    // String str2 = "blogjava223";
    Main main = new Main();
    main.checkDuplicate(str1);
    
}

    public void checkDuplicate(String str1) {
        Map<Character, Integer> map = new HashMap<>();
        char[] ch = str1.toCharArray();
        for(char c : ch){
            if(map.containsKey(c)) {
                map.put(c, map.get(c)+1);
            } else {
                map.put(c, 1);
            }
    }
    
    for(Character cr : map.keySet()){
        if(map.get(cr) >1){
            System.out.println("duplicate character : " + cr + " having count : " + map.get(cr));
        }
    }
    }
}

