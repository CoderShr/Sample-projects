/* package codechef; // don't place package name! */

import java.util.*;
import java.lang.*;
import java.io.*;
import java.util.stream.*;

/* Name of the class has to be "Main" only if the class is public. */
class Main
{
 public static void main(String args[])  
{  
    int[] a = {3,4,7,0,2,6,1,7,45,68,2,4,7,24,89,42};
    System.out.println("Before sorting:");  
    for(int i = 0; i<a.length; i++){
        System.out.print(a[i] + " "); 
    }
    
    int temp = 0;
   for(int i=0; i< a.length; i++){
       for(int j=i+1; j<a.length; j++){
           if(a[i] < a[j]){
               temp = a[i];
               a[i] = a[j];
               a[j] = temp;
           }
       }
   }
    Set<Integer> set = new LinkedHashSet<>();
    
    System.out.println("\nAfter sorting:");  
    for(int i = 0; i<a.length; i++){
        System.out.print(a[i] + " "); 
        set.add(a[i]);
    }

    System.out.println("\nDecending sort:"); 
    Arrays.sort(array, Collections.reverseOrder());   
    
    System.out.print(set);
    
    Integer[] arr = new Integer[set.size()];
    arr = set.toArray(arr);
    
     System.out.println("\n3rd largest:  ");  
     System.out.println(arr[2]); 
      
     System.out.println("\n2nd largest:  ");  
     System.out.println(arr[1]); 
      
     System.out.println("\n largest:  ");  
     System.out.println(arr[0]); 
      
     System.out.println("\n4th smallest:  ");  
     System.out.println(arr[arr.length-4]); 
     
     System.out.println("\n3rd smallest:  ");  
     System.out.println(arr[arr.length-3]); 
     
     System.out.println("\n2nd smallest:  ");  
     System.out.println(arr[arr.length-2]); 
      
     System.out.println("\n smallest:  ");  
     System.out.println(arr[arr.length-1]); 
      
     
}  
}

