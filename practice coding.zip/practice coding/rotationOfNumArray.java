/* package codechef; // don't place package name! */

import java.util.*;
import java.lang.*;
import java.io.*;
import java.util.stream.*;

/* Name of the class has to be "Main" only if the class is public. */
class Main
{
 public static void main(String args[])  
   {  
       
       int[] numArray = {3,5,4,6,8,10,9,2};
       int startIndex = 0;
       int endIndex = numArray.length-1;
       int temp = 0;
       System.out.print("Original array :   ");
        for(int i : numArray){
          System.out.print(i + " ");
      }
       while(startIndex <= endIndex){
           temp = numArray[startIndex];
           numArray[startIndex] = numArray[endIndex];
           numArray[endIndex] = temp;
           
           startIndex ++;
           endIndex --;
       }
       System.out.println();
       System.out.print("Rotated array :  ");
      for(int i : numArray){
          System.out.print(i + " ");
      }
   }
  
}

