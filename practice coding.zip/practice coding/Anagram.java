
// Online IDE - Code Editor, Compiler, Interpreter
import java.util.*;

public class Main
{
    public static void main(String[] args) {
    
        String first = "weeblei";
        String second = "leeebew";
        checkAnagram(first, second);
    }
    public static void checkAnagram(String first, String second){
       if(first.length() == second.length()){
           char[] firstCharArray = first.toLowerCase().toCharArray();
           char[] secondCharArray = second.toLowerCase().toCharArray();
           if(sortArray(firstCharArray).equals(sortArray(secondCharArray))){    
                System.out.println("given string are  anagram");
           
             } else{
           System.out.println("given string are not anagram");
        }
        
        }
    }
    
    public static String sortArray(char[] charArray){
        Arrays.sort(charArray);
        return String.valueOf(charArray);
        
    }
}
