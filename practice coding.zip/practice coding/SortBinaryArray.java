/* package codechef; // don't place package name! */

import java.util.*;
import java.lang.*;
import java.io.*;

/* Name of the class has to be "Main" only if the class is public. */
class Main
{
	public static void main (String[] args) throws java.lang.Exception
	{
	    int[] numArray = new int[]{1,0,1,0,0,0,1,0,1,1,1,1};
	    
	    Main main = new Main();
	   
	    main.sort(numArray);
	}
	
	public void sort(int[] intArray){
	    int count = 0;
	   for (int i : intArray){
	       if(i == 0){
	           count ++;
	       } 
	   }
	   
	  for(int i =0; i < count; i++){
	      intArray[i] = 0;
	  }
	  
	  for(int i =count ; i < intArray.length; i++){
	      intArray[i] = 1;
	  }
	 
	 for(int i : intArray){
	 System.out.print(i);
	}
}
}
