/* package codechef; // don't place package name! */

import java.util.*;
import java.lang.*;
import java.io.*;
import java.util.stream.*;

/* Name of the class has to be "Main" only if the class is public. */
class Main
{
 public static void main(String args[])  
   {  
        List < Product > productsList = new ArrayList < Product > ();
        // Adding Products
        productsList.add(new Product(1, "HP Laptop", 25000));
        productsList.add(new Product(2, "Dell Laptop", 30000));
        productsList.add(new Product(3, "Lenevo Laptop", 28000));
        productsList.add(new Product(4, "Sony Laptop", 28000));
        productsList.add(new Product(5, "Apple Laptop", 90000));
        
        System.out.print(productsList.stream().filter(e -> e.getPrice()>20000).map(e -> e.getName()).findFirst());
        System.out.println();
        
        System.out.print(productsList.stream().filter(e -> e.getPrice()>28000).map(e -> e.getName()).collect(Collectors.toSet()));
        System.out.println();
        
        productsList.stream().filter(e -> e.getPrice()>20000).map(e -> e.getName()).forEach(System.out::print);
        System.out.println();
        
      Product productA = productsList.stream()
            .min((product1, product2) -> product1.getPrice() > product2.getPrice() ? 1 : -1).get();

        System.out.println(productA.getPrice());
        // min() method to get min Product price
        Product productB = productsList.stream()
            .max((product1, product2) -> product1.getPrice() > product2.getPrice() ? 1 : -1).get();
        System.out.println(productB.getPrice());
  System.out.println();

    productsList.stream().map(e -> e.getName()).sorted(String :: compareToIgnoreCase).forEach(System.out::print);
 System.out.println();
  System.out.println(productsList.stream().mapToDouble(e -> e.getPrice()).sum());
  
  
  System.out.println("sort operations");
   Collection<String> collection = Arrays.asList("JAVA", "J2EE", "Spring", "Hibernate");
   System.out.println();
   collection.stream().sorted((e1,e2) -> e1.compareTo(e2)).forEach(System.out::print);
   System.out.println();
   collection.stream().sorted(Comparator.naturalOrder()).forEach(System.out::print);
   System.out.println();
   collection.stream().sorted(String :: compareToIgnoreCase).forEach(System.out::print);
   System.out.println();
   collection.stream().sorted((e1,e2) -> e2.compareTo(e1)).forEach(System.out::print);
   System.out.println();
   collection.stream().sorted(Comparator.reverseOrder()).forEach(System.out::print);
   System.out.println();
   System.out.println("test test");
   collection.forEach(System.out::println);
  
   }
}


class Product {
    
    int id;
    String name;
    float price;
    
    Product (int id, String name, float price){
        this.id = id;
        this.name = name;
        this.price = price;
    }
    
    public int getId(){
        return this.id;
    }
    
    public String getName(){
        return this.name;
    }
    public float getPrice(){
        return this.price;
    }
    
    @Override
    public String toString(){
        return this.id + " " + this.name + " " + this.price;
    }
}

