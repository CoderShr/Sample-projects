/* package codechef; // don't place package name! */

import java.util.*;
import java.lang.*;
import java.io.*;

public class Main
{
    public static void main(String[] args) {
    String str1 = "java2blog";
    String str2 = "blogjava2";
    Main main = new Main();
    main.checkIfRotation(str1, str2);
    
}

    public void checkIfRotation(String str1, String str2){
       String str3 = str1 +str1;
      boolean isRotational = str3.contains(str2);
      System.out.println(str3);
        if(isRotational){
            System.out.println(str1 + " and " + str2 + "  rotational");
        } else{
        System.out.println(str1 + " and " + str2 + " are non-rotational");
    }
    }
}

