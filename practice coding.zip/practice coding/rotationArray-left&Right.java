import java.util.Scanner;
import java.util.*;

public class Main {
    public static void main(String args[]) {
        Scanner scan = new Scanner(System.in);
        System.out.println("\nEnter rotation key");
        int k = scan.nextInt();
        char[] charCharLeft = new char[]{'r','y','t','e','u','w','v','i','n'};
        System.out.println("\n Original array : ");
        System.out.println(Arrays.toString(charCharLeft));
        leftRotation(k, charCharLeft);
        // permute(s, answer);
        char[] charCharRight = new char[]{'r','y','t','e','u','w','v','i','n'};
        rightRotation(k, charCharRight);
        
    }
    
    public static void leftRotation(int k, char[] charChar){
        
        char startElem;
        for(int j = 0; j<k; j++) {
            startElem = charChar[0];  
            int i =0;  
            while(i< charChar.length-1){
                charChar[i] = charChar[i+1];
                i++;
            }
            charChar[charChar.length -1] = startElem;
        }
        System.out.println("\n Left rotated array : ");
        System.out.println(Arrays.toString(charChar));
    }
    
    public static void rightRotation(int k, char[] charChar){
        System.out.println("\n Original array : ");
        System.out.println(Arrays.toString(charChar));
        char endElem;
        for(int j = 0; j<k; j++) {
            endElem = charChar[charChar.length-1];  
            int i = charChar.length-1;  
            while(i>0){
                charChar[i] = charChar[i-1];
                i--;
            }
            charChar[0] = endElem;
        }
        System.out.println("\n Right rotated array : ");
        System.out.println(Arrays.toString(charChar));
    }
}