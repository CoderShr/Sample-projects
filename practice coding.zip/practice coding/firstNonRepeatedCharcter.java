/* package codechef; // don't place package name! */

import java.util.*;
import java.lang.*;
import java.io.*;

public class Main
{
    public static void main(String[] args) {
        String str1 = "malayalame";
        
        Main main = new Main();
      Character c = main.findFirstNonRepeatedCharcterInString(str1);
        if(c != null){
             System.out.println(c);
        }
    }
    
    public Character findFirstNonRepeatedCharcterInString(String str1) {
        Map<Character, Integer> mp = new LinkedHashMap<>();
        char[] charStr = str1.toCharArray();
        for(char ch : charStr){
            if(mp.containsKey(ch)){
                mp.put(ch, mp.get(ch)+1);
            } else {
                mp.put(ch, 1);
            }
        }
        
        for(Map.Entry<Character, Integer> map : mp.entrySet()){
            // System.out.println(map.getKey() + "-" + map.getValue());
            if(map.getValue() == 1){
               return map.getKey();
            }
        }
        return null;
    }
      
      
      
    
    
}

