
// Online IDE - Code Editor, Compiler, Interpreter
import java.util.*;

public class Main
{
    public static void main(String[] args) {

    Main main = new Main();
    main.getLength("Hello world, hope you good");
    
}

    public void getLength(String str){
        int length = 0;
        char[] strCh = str.toCharArray();
        for(char c : strCh){
            length++;
        }
        System.out.println("\"Hello world\"" + " line length is : " + length);
    }
}
