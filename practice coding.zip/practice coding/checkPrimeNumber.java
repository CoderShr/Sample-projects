/* package codechef; // don't place package name! */

import java.util.*;
import java.lang.*;
import java.io.*;

/* Name of the class has to be "Main" only if the class is public. */
class Main
{
	public static void main (String[] args) throws java.lang.Exception
	{
	   
	    
	    Main main = new Main();
	    Scanner sc = new Scanner(System.in);
	    
	   
	    main.checkPrime(sc.nextInt());
	}
	
	public void checkPrime(int num){
	    int flag = 1;
	    if(num == 0 || num == 1 ){
	         System.out.println(num +" number is not prime");
	    } else {
    	    for(int i =2; i< num/2; i++){
	            if( num%i == 0) {
	                flag = 1;
	                break;
	            } else {
	                flag = 0;
	       }
	    }
	    }
	   if(flag == 0 ){
	       System.out.println(num +" number is prime");
	   } else if(flag ==1) {
	       System.out.println(num +" number is not prime");
	   }
	}
	
}
