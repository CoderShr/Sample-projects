/* package codechef; // don't place package name! */

import java.util.*;
import java.lang.*;
import java.io.*;

/* Name of the class has to be "Main" only if the class is public. */
class Main
{
	public static void main (String[] args) throws java.lang.Exception
	{
	    int[] numArray = new int[]{0,1,0,0,0,0,0,1,1,1,1,1,1,1,0,0,0,0};
	    Main main = new Main();
	    int num = main.find1sOccuranceInBinaryArray(numArray);
	    System.out.println(num);
	}
	
	public int find1sOccuranceInBinaryArray(int[] intArray){
	    Arrays.sort(intArray);
	    int currentPointer = 0; 
	    int count = 0;
	    for(int i : intArray){
	        if(i == 1){
	            break;
	           
	        } else {
	            count++;
	        }
	        currentPointer ++ ;
	    }
	    System.out.println("occurance of zeros : " + count);
	    return (intArray.length - currentPointer );
	}
}
