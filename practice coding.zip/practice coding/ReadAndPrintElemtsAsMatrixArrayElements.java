/* package codechef; // don't place package name! */

import java.util.*;
import java.lang.*;
import java.io.*;
import java.util.stream.*;

class Main {
 public static void main(String args[]) {  
       
      // how to accept and print 2x2 matix elements
      Scanner sc = new Scanner(System.in);

      System.out.println("Enter number of rows of matrix :");
      int r = sc.nextInt();
      System.out.println("Enter number of columns of matrix :");
      int c = sc.nextInt();
      int[][] matrixArray = new int[r][c];
      System.out.println("Enter elements of array matrix :");
      for(int i =0;i< r; i++){
          for(int j=0; j<c; j++){
                matrixArray[i][j] = sc.nextInt();  
          }
      }
      
      System.out.println("Matrix arry elements are : ");
      for(int i =0;i< r; i++){
          for(int j=0; j<c; j++){
                System.out.print(matrixArray[i][j]  + " ");
          }
          System.out.println();
      }
      
    }  

      
}

