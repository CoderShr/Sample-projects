
// Online IDE - Code Editor, Compiler, Interpreter
import java.util.*;

public class Main
{
    public static void main(String[] args) {
    
        String first = "weeblei";
        reverseString(first);
    }
    public static void reverseString(String first){
        char[] str = first.toCharArray();
        String reversedStr = "";
        for(int i = str.length-1; i>=0; i--){
            reversedStr += str[i];
        }
        System.out.println(reversedStr);
        }
    
}
