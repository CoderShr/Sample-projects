/* package codechef; // don't place package name! */

import java.util.*;
import java.lang.*;
import java.io.*;

/* Name of the class has to be "Main" only if the class is public. */
class Main
{
 public static void main(String args[])  
   {  
     int num = 5;
     List<Integer> list = new ArrayList<>();
     Main main = new Main();
     
     System.out.println(main.findIsAmstrong(155));
      System.out.println(main.findIsAmstrong(153));
      
        System.out.println(main.findIsAmstrong(407));
}

    public boolean findIsAmstrong(int num){
        int temp = num, digit = 0, power =0, sum =0; 
        int last=0;
        while(temp>0){
            temp/= 10;
            digit ++;
        }
        temp = num;
        while(temp > 0){
            for(int i =0; i< digit; i++){
                last = temp%10;
                sum +=  (Math.pow(last, digit));   
                temp = temp/10;
            }
        }
        if(num == sum){
                return true;
        }else {
        return false;
        }
    }
}
