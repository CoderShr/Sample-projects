
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

public class Main
{
    public static void main(String[] args) {
        String[] array1
            = {"A", "B", "C", "D", "E", "B", "C",  "E", "B", "C"};
        String[] array2
            = {"E", "B", "C",  "E", "B", "C", "A", "B", "C", "D"};
        checkArrayIdentical(array1, array2);
    
    }
    
    public static void checkArrayIdentical(String[] ch1, String[] ch2){
        if(ch1.length == ch2.length ){
            checkArraysIdenticalWithSort(ch1, ch2);
            isIdenticalUsingJava8Streams(ch1, ch2);
        } else {
            System.out.println("length not equal");
            System.out.println("Arrays are not identical");
        }
    }
    
    public static void checkArraysIdenticalWithSort(String[] ch1, String[] ch2){
        Arrays.sort(ch1);
        Arrays.sort(ch2);
        boolean isIdentical = false;
        if(ch1.length == ch2.length){
            for(int i= 0; i< ch1.length; i++){
                if(ch1[i] == ch2[i]){
                    isIdentical = true;
                } else {
                    isIdentical = false;
                }
            }
        } 
        isIdenticalArrays(isIdentical);
    }
    
    public static void isIdenticalUsingJava8Streams(String[] array1, String[] array2){
    //   // to convert array to list
    //     List list = new ArraysList();
    //     Collections.addAll(list, array1);
    //     or,
    //     Lists.newArrayList(array1);
    //     or, 
    //     Arrays.stream(array1).collect(Collectors.toList());
        
        
        Map<String, Long> map1 = Arrays.stream(array1).collect(
                                        Collectors.groupingBy(
                                            Function.identity(),
                                            Collectors.counting()));
       Map<String, Long> map2 = Arrays.stream(array2).collect(
                                        Collectors.groupingBy(
                                            Function.identity(),
                                            Collectors.counting()));
        System.out.println(map1);
        System.out.println(map2);
        isIdenticalArrays(map1.equals(map2));
    }
    
    public static void isIdenticalArrays(boolean isIdentical){
        if(isIdentical){
            System.out.println("Arrays are identical");
        } else {
            System.out.println("Arrays are not identical");           
        }
    }
}
