/* package codechef; // don't place package name! */

import java.util.*;
import java.lang.*;
import java.io.*;
import java.util.stream.*;

class Main {
 public static void main(String args[]) {  
       
        int[] numArray = {34,89,23,90,76,80,60,73,0};
        int startIndex = 0;
        int location = 3;
        int number = 45;
        Scanner sc = new Scanner(System.in);
        System.out.print("Array elements:   " + Arrays.toString(numArray));
        for(int j = numArray.length-1; j > location; j--) {
           numArray[j] = numArray[j-1];
           System.out.println("in the loop");
        }
        numArray[location] = number;
        System.out.println();
        System.out.print("Array with Inserted elements  :  " + Arrays.toString(numArray));
        
   }
  
}

