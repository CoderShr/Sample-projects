/* package codechef; // don't place package name! */

import java.util.*;
import java.lang.*;
import java.io.*;
import java.util.stream.*;

class Main {
 public static void main(String args[]) {  
       
        int[] numArray = {10,20,30,40,50,60,70,80,90};
        System.out.print("\nArray elements:   " + Arrays.toString(numArray));
        // left rotation of array by one position
        rotateLeftByOnePosition(numArray);
        int[] numArray1 = {10,20,30,40,50,60,70,80,90};
        // right rotation of array by one position
        rotateRightByOnePosition(numArray1);
   }
   
   static void rotateLeftByOnePosition(int[] numArray){
       int temp = numArray[0];
        for(int j = 0; j < numArray.length-1; j++) {
           numArray[j] = numArray[j+1];
        }
        numArray[numArray.length-1] = temp;
        System.out.println();
        System.out.print("\nArray elements after left rotation of array by one position  : " + Arrays.toString(numArray));
   } 
  
    static void rotateRightByOnePosition(int[] numArray){
       int temp = numArray[numArray.length-1];
        for(int i=numArray.length-1; i>0 ; i--) {
           numArray[i] = numArray[i-1];
        }
        numArray[0] = temp;
        System.out.println();
        System.out.print("\nArray elements after right rotation of array by one position  : " + Arrays.toString(numArray));
    }
}

