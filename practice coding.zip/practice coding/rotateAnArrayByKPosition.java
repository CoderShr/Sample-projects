/* package codechef; // don't place package name! */

import java.util.*;
import java.lang.*;
import java.io.*;

/* Name of the class has to be "Main" only if the class is public. */
class Main
{
	public static void main (String[] args) throws java.lang.Exception
	{
	    int[] numArray = new int[]{2,4,6,7,8,9,3,11}; // we need this {9,3,11,2,4,6,7,8}
														
	    int k = 3;

	    Main main = new Main();
	    int length = numArray.length;
	    if(k>length){
	        k = k%length;
	    }
	    // {11,3,9,8,7,6,4,2}
	    main.rotateArrayByKPosition(numArray,0, length-1);
	   // {11,3,9,2,4,6,7,8}
	    main.rotateArrayByKPosition(numArray, 0, k-1);
	    // {9,3,11,2,4,6,7,8}
	    numArray = main.rotateArrayByKPosition(numArray, k, length-1);
	    main.printArray(numArray);
	}
	
	public int[] rotateArrayByKPosition(int[] intArray, int startIndex, int endIndex){
	    int temp;
	    while(startIndex <= endIndex){
	        temp = intArray[startIndex];
	        intArray[startIndex] = intArray[endIndex];
	        intArray[endIndex] = temp;
	        startIndex ++;
	        endIndex --;
	    }
	    return intArray;
	}
	
	public void printArray(int[] intArray){
	    System.out.print("{");
	    for(int i : intArray){
	        System.out.print(" " + i);
	    }
	    System.out.print("}");
	}
}
