/* package codechef; // don't place package name! */

import java.util.*;
import java.lang.*;
import java.io.*;
import java.util.stream.*;

/* Name of the class has to be "Main" only if the class is public. */
class Main
{
 public static void main(String args[])  
   {  
      
      int [] arr = new int [] {1, 2, 3, 4, 2, 7, 8, 8, 3};  
      
         System.out.println("duplicate ones using loop"); 
      for(int i =0; i<arr.length ; i++){
          for(int j =i+1; j <arr.length ; j++ ){
              if(arr[i] == arr[j]){
                  System.out.print(arr[i] + " ");
              }
          }
      }
    
    Map<Integer, Integer> map = new HashMap<>();
    for(int i : arr){
    
        if(map.containsKey(i)){
            map.put(i, map.get(i)+1);
        } else {
            map.put(i, 1);
        }
    }
    
     System.out.println("\n duplicate ones using HashMap");
   for(Map.Entry<Integer, Integer> mp : map.entrySet()){
        if(mp.getValue() > 1){
            System.out.print(mp.getKey() + " ");
        }  
    } 
    
         System.out.println("\n elements with count");
    for(Map.Entry<Integer, Integer> mp : map.entrySet()){
        System.out.println(mp.getKey() + " -" + mp.getValue());
     }
     
          System.out.println("distict ones  ones");
    for(Map.Entry<Integer, Integer> mp : map.entrySet()){
        if(mp.getValue() == 1){
            System.out.print(mp.getKey() + " ");
        }  
    } 
    
   }
   
}

