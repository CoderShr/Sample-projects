/* package codechef; // don't place package name! */

import java.util.*;
import java.lang.*;
import java.io.*;
import java.util.stream.*;

/* Name of the class has to be "Main" only if the class is public. */
class Main
{
 public static void main(String args[])  
{  
    int a=89, b=45;  
    System.out.println("Before swapping:");  
    System.out.println("a = " +a +", b = " +b);  
    
    a = a*b;
    b = a/b;
    a = a/b;
    System.out.println("After swapping:");  
    System.out.print("a = " +a +", b = " +b);  
}  
}

