import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter n:");
        int n = sc.nextInt();
        int[] numArray = new int[]{2,4,5,6,9,3,5,9,3,0,2,1,5};
        int[] result = deleteAnArray(numArray, n);
        System.out.println("\n Array " + Arrays.toString(result));
        // 69 - 44
    }
    
    static int[] deleteAnArray(int[] numArray, int num) {
        int[] deletedArray = new int[numArray.length-1];
        int i = 0; 
        for(int n : numArray){
            if(n != num){
                deletedArray[i] = n;
                i ++;
            }
        }
        return deletedArray;
    } 
   

    }