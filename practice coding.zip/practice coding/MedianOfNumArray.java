
// Online IDE - Code Editor, Compiler, Interpreter
import java.util.*;

public class Main
{
    public static void main(String[] args) {

    int[] numArray = new int[]{20,44,23,56,70,34};
    Main main = new Main();
    main.findMedianOfArray(numArray);
    
}

    public void findMedianOfArray(int[] numArray){
        int lengthh = numArray.length;
        Arrays.sort(numArray);
        for(int i : numArray){
            System.out.print(i + " ");
        }
        if(lengthh % 2 != 0){
            System.out.println();
            System.out.println(numArray[(lengthh/2)]);
        } else {
            // System.out.println("here");
                int midPnt = lengthh/2;
             //   int midNext = midPnt+1;
                float add = numArray[midPnt-1]+ numArray[midPnt];
                float medianNum = add/2;
                System.out.println(medianNum); 
        }
    
    }
}
