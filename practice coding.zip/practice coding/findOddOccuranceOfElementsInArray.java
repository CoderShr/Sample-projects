/* package codechef; // don't place package name! */

import java.util.*;
import java.lang.*;
import java.io.*;

/* Name of the class has to be "Main" only if the class is public. */
class Main
{
	public static void main (String[] args) throws java.lang.Exception
	{
	    int[] numArray = new int[]{40,50,40,60,40,70,80,90,80,70,60,20,40,10,40,20,10};
	    Main main = new Main();
	    main.findOddOccuranceOfElementsInArray(numArray);
	    
	}
	
	public void findOddOccuranceOfElementsInArray(int[] intArray){
	    Map<Integer, Integer> map = new HashMap<>();
	    for(int i : intArray){
	        if(map.containsKey(i)){
	            map.put(i, map.get(i)+1);
	        }else  {
	            map.put(i, 1);
	        }
	    }
	   for (Map.Entry<Integer, Integer> mp : map.entrySet()){
	       if(mp.getValue()%2 != 0 ){
	           System.out.println(mp.getKey() + "-" + mp.getValue());
	   }
	}
	}
}
