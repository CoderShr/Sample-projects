import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a word:");
        String str = sc.nextLine();
        int[] numArr = new int[]{3,2,5,7,6,0,1,9,8};
        String reversedStr = reverseEntireString(str);
        System.out.println("\nReversed string : "  + reversedStr);
        reverseWordsOfString("Welcome to java world of magic");
        reverseElementsInArray(numArr);
    }
    
    static String reverseEntireString(String str) {
        char[] chStr = str.toCharArray();
        String reversedStr = "";
        for(int i=chStr.length-1; i>=0; i--){
            reversedStr += chStr[i];
        }
        return reversedStr;
    }
    
    static void reverseWordsOfString(String str) {
        String[] chStr = str.split("\\s");
        System.out.println("Reversed array words :  ");
        for(int i=chStr.length-1; i>=0; i--){
            System.out.print(chStr[i] + " ");
        }
    }
    
    static void reverseElementsInArray(int[] numArr) {
        System.out.println("\nOriginal array of elements :  \n" + Arrays.toString(numArr));
        System.out.println("\nReversed array of elements :  " );
        for(int i=numArr.length-1; i>=0; i--){
            System.out.print(numArr[i] + " ");
        }
        
        int temp =0, start = 0, end = numArr.length-1;
        while(start< end){
            temp = numArr[start];
            numArr[start] = numArr[end];
            numArr[end] = temp;
            start ++;
            end --;
        }
            System.out.print("\n"+ Arrays.toString(numArr) + " ");
        }
    

    }