
// Online IDE - Code Editor, Compiler, Interpreter
import java.util.*;
import java.util.Map;
import static java.util.stream.Collectors.*;
// Import 

public class Main
{
    public static void main(String[] args) {
        int[] numbers = new int[]{22,88,44,77,66};
        getSecondLargestNumberFromList(numbers);
        
        }
        public static void getSecondLargestNumberFromList(int[] numbers){
            List<Integer> numbersList = new ArrayList<>(numbers.length);
            for(int i : numbers){
                numbersList.add(i);
            }
            System.out.println("Given array : " + numbersList);
            List<Integer> sortedList = numbersList.stream().sorted(Comparator.reverseOrder()).collect(toList());
            System.out.println("Sorted list : " + sortedList);
            System.out.println("Second largest number from list : " + sortedList.get(1));
    }
}

