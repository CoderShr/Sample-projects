
// Online IDE - Code Editor, Compiler, Interpreter

public class Main
{
    public static void main(String[] args) {
    
        int value = 58;
        getSumOfDigits(value);
    }
    public static void getSumOfDigits(int value){
        int sum = 0;
        while(value>10){
            sum += value% 10;
            value = value/10;
        }
            System.out.println(sum+value);
        
    }
}
