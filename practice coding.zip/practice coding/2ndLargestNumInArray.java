/* package codechef; // don't place package name! */

import java.util.*;
import java.lang.*;
import java.io.*;

public class Main
{
    public static void main(String[] args) {
        Main main = new Main();
        int[] numArray = new int[] {2,6,5,43,7,4,8,4,3,8,4,9,3,67,23,78,43,75,99};
        main.findSecondLargestNumInArray(numArray);
        main.findSecondLargestNumInArrayLessTimeComplexity(numArray);
    }
    
    public int findSecondLargestNumInArray(int[] numArray) {
        Arrays.sort(numArray);
        System.out.println(numArray[(numArray.length)-2]);
        return numArray[(numArray.length)-2];
    }
    
     public int findSecondLargestNumInArrayLessTimeComplexity(int[] numArray) {
        int highest = 10;
        int secondHighest = 8;
      for(int i = 0; i < numArray.length; i ++){
          if(numArray[i]> highest){
                secondHighest = highest;
                highest = numArray[i];
            } else if(numArray[i] > secondHighest && numArray[i] != highest ){
                secondHighest = numArray[i];
            }
        }
        System.out.println(secondHighest);
        return secondHighest;
    }
    
    
}

