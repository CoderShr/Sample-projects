/* package codechef; // don't place package name! */

import java.util.*;
import java.lang.*;
import java.io.*;

public class Main
{
    public static void main(String[] args) {
        String str1 = "heloBrista";
        
        Main main = new Main();
       if(main.checkIfGivenStringHaveUniqueChar(str1)){
           System.out.println("String is unique");
       } else {
           System.out.println("String not unique");
       }
        
    }
    
    public boolean checkIfGivenStringHaveUniqueChar(String str1) {
      char[] strCh = str1.toCharArray();
      boolean isUnique = false;
      Set<Character> set = new HashSet<>();
      for (char ch : strCh){
         if(!set.add(ch)){
             return false;
         }
      }
      return true;
    }
      
      
      
    
    
}

