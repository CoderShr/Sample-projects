/* package codechef; // don't place package name! */

import java.util.*;
import java.lang.*;
import java.io.*;
import java.util.stream.*;

/* Name of the class has to be "Main" only if the class is public. */
class Main
{
 public static void main(String args[])  
   {  
      
      int [] arr = {1, 2, 3, 4, 2, 7, 8, 8, 3};  
      
      System.out.println("even index elements in array");
      for(int i =1; i< arr.length; i = i+2){
          System.out.print(arr[i] + " ");
      }
      
      System.out.println("\nodd index elements in array");
      for(int i =0; i< arr.length; i= i+2){
          System.out.print(arr[i] + " ");
      }
      
      System.out.println("\nodd elements in array");
      for(int i =0; i< arr.length; i++){
          if(arr[i] %2 != 0)
          System.out.print(arr[i] + " ");
      }
      
      System.out.println("\neven elements in array");
      for(int i =0; i< arr.length; i++){
          if(arr[i] %2 == 0)
          System.out.print(arr[i] + " ");
      }
      
      
       System.out.println("\nlargest elements in the array");
       int largest = arr[0];
      for(int i =0; i< arr.length-1; i++){
          if(arr[i] > arr[i+1])
          largest = arr[i];
      }
      System.out.println(largest);
      
       System.out.println("\nSmallest elements in the array");
       int smallest = arr[0];
      for(int i =0; i< arr.length-1; i++){
          if(arr[i] < arr[i+1])
          smallest= arr[i];
      }
      System.out.println(smallest);
      
   
   
     System.out.println("\nNumber of elements in array : " + arr.length + "\nThrough loop without inbuild methods: ");
     int digit = 0;
      for(int i =0; i< arr.length; i++){
         digit ++ ;
      }
      System.out.println(digit);
   
   
   
   System.out.println("\nsum of elements in array");
   int sum = 0;
      for(int i =0; i< arr.length; i++){
          sum += arr[i];
      }
          System.out.print(sum);
      
    }
}

