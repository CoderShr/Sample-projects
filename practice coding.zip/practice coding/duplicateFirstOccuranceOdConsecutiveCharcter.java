
// Online IDE - Code Editor, Compiler, Interpreter
import java.util.*;
import java.util.Map;
import static java.util.stream.Collectors.*;
// Import 
public class Main
{
    public static void main(String[] args) {
        System.out.println("Welcome to Online IDE!! Happy Coding :)");
        String val1 = "weellcoome";
        getFirstOccuranceOfDuplicateConsecutiveAlphabet(val1);
        String val2 = "w";
        getFirstOccuranceOfDuplicateConsecutiveAlphabet(val2);
        String val3 = "ww";
        getFirstOccuranceOfDuplicateConsecutiveAlphabet(val3);
        String val4 = "";
        getFirstOccuranceOfDuplicateConsecutiveAlphabet(val4);
    }

        public static void getFirstOccuranceOfDuplicateConsecutiveAlphabet(String strLine){
            char[] chars = strLine.toCharArray();
             Map<String, Integer> duplicateOccurnceMap = new HashMap<>(strLine.length());
            if(chars.length <= 1){
                System.out.println("Will throw array index out of bound exception");
            }
            for(int i = 0; i< chars.length; i++){
                if(i+1 < chars.length && chars[i] == chars[i+1]){
                    duplicateOccurnceMap.put(String.valueOf(chars[i]), i);
                }
            }
            for (Map.Entry<String, Integer> map : duplicateOccurnceMap.entrySet()){
            System.out.println(map.getKey() +"-" + map.getValue());
            }
        }
}

