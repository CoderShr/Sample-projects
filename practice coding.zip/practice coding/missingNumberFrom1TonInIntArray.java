/* package codechef; // don't place package name! */

import java.util.*;
import java.lang.*;
import java.io.*;

/* Name of the class has to be "Main" only if the class is public. */
class Main
{
	public static void main (String[] args) throws java.lang.Exception
	{
	    int[] numArray = new int[]{1,3,2,4,5,6,7,8,9,10,11,12,13,14,15,17};
	    
	    Main main = new Main();
	   
	    main.findMissingNumber(numArray);
	}
	
	public void findMissingNumber(int[] intArray){
	   int n = intArray.length+1;
	   int sum = n*(n+1)/2;
	   int restSum = 0;
	   for(int i : intArray){
	       restSum += i; 
	   }
	   
	   System.out.println(sum-restSum);
	}
}
