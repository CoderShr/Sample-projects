import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter n:");
        int n = sc.nextInt();
        int result = coprimeNumbers(n);
        // int result = findHCF(7,15);
        System.out.println("Count of coprimes of num " + n + " is : " + result);

    }
    
    static int coprimeNumbers(int n) {
        int countOfCoprimeNumbers = 1, hcf;
        List<Integer> factorsArrayofn = new ArrayList<>();
        for (int i = 2; i <= n; i++) {
            if (n % i == 0) {
                factorsArrayofn.add(i);
            }
        }

        System.out.println("Factors of n:" +factorsArrayofn);
        for (int num = 2; num <= n; num++){
            hcf = findHCF(n, num);
            if(hcf == 1){
                countOfCoprimeNumbers ++;
            }
        }
        return countOfCoprimeNumbers;
    }


    public static int findHCF(int a, int b) {
        // System.out.println("a :" + a + " b : " + b);
        if(a==0)
          return b;
        else
        //   System.out.println("b%a : " + b%a + " a : " + a);
          return findHCF(b%a,a);
    }
}