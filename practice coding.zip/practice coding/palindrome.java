/* package codechef; // don't place package name! */

import java.util.*;
import java.lang.*;
import java.io.*;

/* Name of the class has to be "Main" only if the class is public. */
class Main
{
	public static void main (String[] args) throws java.lang.Exception
	{
	   
	    
	    Main main = new Main();
	    Scanner sc = new Scanner(System.in);
	    
	   
	    main.palinedrome(sc.nextInt());
	}
	
	public void palinedrome(int num){
	    int i, rem =0, sum =0;
	    int temp = num;
	    for( i = 0; i< num ; i++){
	        rem = num%10;
	        sum = (sum*10)+rem;
	        num = num/10;
	    }
	    
	    if(temp == sum){
	        System.out.println("Num is palindrome");
	    } else {
	        System.out.println("Num is not palindrome");
	    }
	}
	
}
