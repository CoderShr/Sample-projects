
// Online IDE - Code Editor, Compiler, Interpreter
import java.util.*;
import java.util.function.*;
import java.lang.*;
import static java.util.stream.Collectors.*;

public class Main
{
    public static void main(String[] args) {
        char[] ch1 = new char[]{'X','Y','Z', 'A'};
        char[] ch2 = new char[]{'A','Y','Z','Y','E'};
        char[] ch3 = new char[]{'A','X','Z','Y'};
  
        checkArrayIdentical(ch1, ch2);
        checkArrayIdentical(ch1, ch3);
        checkArrayIdentical(ch2, ch3);
    }
    
    public static void checkArrayIdentical(char[] ch1, char[] ch2){
        if(ch1.length == ch2.length ){
            checkArraysIdenticalWithSort(ch1, ch2);
            checkArraysIdenticalWithOutSort(ch1, ch2);
        }else {
            System.out.println("length not equal");
            System.out.println("Arrays are not identical");
        }
    }
    
    public static void checkArraysIdenticalWithSort(char[] ch1, char[] ch2){
        Arrays.sort(ch1);
        Arrays.sort(ch2);
        boolean isIdentical = false;
        if(ch1.length == ch2.length){
            for(int i= 0; i< ch1.length; i++){
                if(ch1[i] == ch2[i]){
                    isIdentical = true;
                } else {
                    isIdentical = false;
                }
            }
        } 
        isIdenticalArrays(isIdentical);
    }
    
    public static void checkArraysIdenticalWithOutSort(char[] ch1, char[] ch2){
        Map<Character, Integer> map1 = new HashMap<>();
        Map<Character, Integer> map2 = new HashMap<>();
        for(int i=0; i< ch1.length; i++) {
           map1 = populateMap(map1, i , ch1);
           map2 = populateMap(map2, i , ch2); 
        }
        
        isIdenticalArrays(map1.equals(map2));
    }
    
    public static Map<Character, Integer> populateMap( Map<Character, Integer> map1, int i, char[] ch1){
         if(map1.containsKey(ch1[i])){
                map1.put(ch1[i], map1.get(i) + 1);
            } else {
                map1.put(ch1[i], 1);
            }
            return map1;
    } 
    
    public static void isIdenticalArrays(boolean isIdentical){
        if(isIdentical){
            System.out.println("Arrays identical");
        } else {
            System.out.println("Arrays are not identical");           
        }
    }
    
}
