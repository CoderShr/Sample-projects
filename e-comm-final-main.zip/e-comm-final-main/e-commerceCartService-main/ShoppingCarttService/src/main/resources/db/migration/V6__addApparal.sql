INSERT INTO apparal (brand, design, type, product_id)
VALUES ("Levis", "Men's Solid Regular Fit Casual Shirt", "Shirt", 7),
("Pepe", "Men's Denim Slim Fit Strechable Jeans", "Jeans", 8),
("Tommy Hilfiger", "Boys Round Neck Blended Cotton Tshirt -Combo Pack of 5", "T-Shirts", 9),
("Biba", "Women's Pure Cotton Printed Straight Kurti", "Kurtis", 10),
("Soch", "Women's Woven Silk Blend Saree With Blouse Piece", "Sarees", 11),
("Nike", "Nike Men's Athletic Track Pants", "Pants", 12)