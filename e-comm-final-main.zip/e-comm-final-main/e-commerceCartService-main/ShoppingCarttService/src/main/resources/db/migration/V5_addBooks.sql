INSERT INTO book (author, genre, publications, product_id)
VALUES ("Morgan Housel", "Business", "Jaico Publishing House", 1),
("Napoleon Hill", "Business", "Srishti Publishers & Distributors", 2),
("George S. Clason", "Business", "Rupa Publications India", 3),
("Khorshed Bhavnagri", "Spiritual", "Jaico Publishing House", 4),
("Gaur Gopal Das", "Spiritual", "Penguin Ananda", 5),
("A.P.J. Abdul Kalam", "History","HarperCollins", 6),