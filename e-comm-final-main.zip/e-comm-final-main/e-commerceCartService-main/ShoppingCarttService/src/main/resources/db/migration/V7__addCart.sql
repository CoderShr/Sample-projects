INSERT INTO cart (cart_id, product_id, user_id, quantity)
VALUES (1, 1, 1, 10),
(2, 7, 1, 2),
(3, 10, 2, 10)