INSERT INTO user (user_id, user_name, first_name, last_name, address, email_id)
VALUES (1, "fyewen0", "Felicdad", "Yewen", "79 6th Crossing	", "fyewen0@gmail.com"),
        (2, "gdoidge1", "Gonzalo", "Doidge", "29961 4th Trail", "gdoidge1@gmail.jp")