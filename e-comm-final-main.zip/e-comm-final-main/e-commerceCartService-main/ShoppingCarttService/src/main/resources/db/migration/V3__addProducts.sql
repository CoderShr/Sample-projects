INSERT INTO product (product_id, product_name, price, catagory)
VALUES  (1, "The Psychology of Money", 285.0, "Book"),
(2, "Think & Grow Rich", 109.0, "Book"),
(3, "The Richest Man in Babylon", 70.0, "Book"),
(4, "The Laws of the Spirit World", 275.0, "Book"),
(5, "Life's Amazing Secrets", 214, "Book"),
(6, "Turning Points : A Journey Through Challenges", 210, " Book"),
(7, "Casual Shirts", 2000, "Apparal"),
(8, "Jeans", 1200, "Apparal"),
(9, "T-Shirts", 800, "Apparal"),
(10, "Kurtis", 1300, "Apparal"),
(11, "Sarees", 1800, "Apparal"),
(12, "Track Pants", 700, "Apparal");