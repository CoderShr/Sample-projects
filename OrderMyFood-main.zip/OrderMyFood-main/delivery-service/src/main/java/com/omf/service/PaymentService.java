package com.omf.service;

import com.omf.model.Payment;

public interface PaymentService {
    void processPayment(Payment payment);
}
