# Setup Restaurant Test Environment

## Test Restaurant ID
11111111-1111-1111-11111111111111111

## Pre-load menu items for test restaurant
sh upload-menuItems.sh

## List all menu items for test restaurant
localhost:8001/api/restaurants/11111111-1111-1111-11111111111111111/menuItems
