package com.food.order.ordermanagementservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrderManagementServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
